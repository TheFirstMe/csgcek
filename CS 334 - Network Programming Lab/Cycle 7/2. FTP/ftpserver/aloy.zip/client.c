#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<string.h>
#include<stdlib.h>

#define bzero(b,len) (memset((b), '\0', (len)), (void) 0)
#define PORT 8887

void error(const char *msg){
    perror(msg);
    exit(1);
}

int main(){
    int sockfd;
    struct sockaddr_in serv_addr;
    char buffer[256];
    char test[256];
    FILE *fp;

    sockfd = socket(AF_INET,SOCK_STREAM,0);
    
    memset(&serv_addr,0,sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(PORT);

    connect(sockfd, (struct sockaddr*) &serv_addr, sizeof(serv_addr));
    int a;
    system("clear");
    printf("\nEnter file name: ");
    scanf("%s",buffer);

    a=send(sockfd,buffer,strlen(buffer)+1,0);
    if(a<0){
        error(" Hmm1 ");
    }
    strcpy(test,buffer);
    fp = fopen(buffer,"wb");
    
    int flag=0;
    while(1){
        bzero(buffer,256);
        a=recv(sockfd,buffer,sizeof(buffer),0);
        if(a<0){
            error(" Hmm ");
        }
        if(strcmp(buffer,"error")==0){
            a=recv(sockfd,buffer,sizeof(buffer),0);
            if(a<0){
                error(" Hmm5 ");
            }
            printf("\n%s\n",buffer);
            remove(test);
            break;
        }
        else if(strcmp(buffer,"success")==0){
            a=recv(sockfd,buffer,sizeof(buffer),0);
            if(a<0){
                error(" Hmm6 ");
            }
            printf("\n%s\n",buffer);
            continue;
        }
        if(a==0)
            break;
        fwrite(buffer,1,a,fp);
    }
    getchar();
    fclose(fp);
    // printf("\nMessage: %s",buffer);
    // close(sockfd);
    return 0;
}